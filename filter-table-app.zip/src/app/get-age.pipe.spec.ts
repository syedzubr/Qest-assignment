import { GetAgePipe } from './get-age.pipe';

describe('GetAgePipe', () => {
  it('create an instance', () => {
    const pipe = new GetAgePipe();
    expect(pipe).toBeTruthy();
  });
});
